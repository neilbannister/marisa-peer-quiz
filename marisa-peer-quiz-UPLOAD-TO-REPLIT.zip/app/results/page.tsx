'use client';

import { useSearchParams } from 'next/navigation';
import { useState, useEffect, Suspense } from 'react';
import { motion } from 'framer-motion';
import { archetypes } from '@/lib/archetypes';
import { Archetype } from '@/lib/scoring';

function ResultsContent() {
  const searchParams = useSearchParams();
  const userId = searchParams.get('id');
  const archetypeKey = searchParams.get('archetype') as Archetype;
  const nameParam = searchParams.get('name') || '';

  const [phase, setPhase] = useState<'analyzing' | 'reveal' | 'details'>('analyzing');
  const [userData, setUserData] = useState<any>(null);
  const [reportReady, setReportReady] = useState(false);

  const archetype = archetypes[archetypeKey] || archetypes.quiet_powerhouse;
  const name = userData?.name || nameParam || 'friend';

  // Fetch user data if we have an ID
  useEffect(() => {
    if (userId) {
      fetch(`/api/quiz/submit?id=${userId}`)
        .then(r => r.json())
        .then(data => setUserData(data))
        .catch(() => {});
    }
  }, [userId]);

  // Analyzing phase timing
  useEffect(() => {
    const t1 = setTimeout(() => setPhase('reveal'), 3000);
    const t2 = setTimeout(() => setPhase('details'), 5000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  // Trigger report generation in background
  useEffect(() => {
    if (userId && phase === 'reveal') {
      fetch('/api/report/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      })
        .then(r => r.json())
        .then(() => setReportReady(true))
        .catch(() => {});
    }
  }, [userId, phase]);

  // Copy share link
  const shareUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const shareText = archetype.shareText;

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'What Were You Born To Do?', text: shareText, url: shareUrl });
      } catch {}
    } else {
      navigator.clipboard.writeText(`${shareText}\n\n${shareUrl}`);
      alert('Copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen bg-brand-cream flex flex-col items-center justify-center px-4 py-16">
      {/* ─── ANALYZING PHASE ─── */}
      {phase === 'analyzing' && (
        <motion.div
          className="text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="w-16 h-16 mx-auto mb-8 border-3 border-brand-gold/30 border-t-brand-gold rounded-full"
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1.2, ease: 'linear' }}
          />
          <h2 className="text-2xl font-serif text-brand-dark mb-3">
            Analysing {name}'s responses...
          </h2>
          <div className="space-y-2 text-sm text-brand-dark/40">
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
              Mapping subconscious patterns...
            </motion.p>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }}>
              Identifying core belief system...
            </motion.p>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2 }}>
              Generating personalised insights...
            </motion.p>
          </div>
        </motion.div>
      )}

      {/* ─── REVEAL PHASE ─── */}
      {(phase === 'reveal' || phase === 'details') && (
        <motion.div
          className="max-w-xl w-full text-center"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
        >
          <p className="text-brand-gold text-sm tracking-wide mb-4">
            {name}, your results are in...
          </p>

          {/* Archetype Card */}
          <motion.div
            className={`bg-gradient-to-br ${archetype.colorBg} rounded-3xl p-8 md:p-12 shadow-xl mb-8 relative overflow-hidden`}
            initial={{ rotateY: 90 }}
            animate={{ rotateY: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {/* Decorative element */}
            <div className="absolute top-4 right-4 text-6xl opacity-10"
              style={{ color: archetype.color }}>
              {archetype.emoji}
            </div>

            <p className="text-xs uppercase tracking-[0.3em] mb-4 opacity-50">
              Your True Calling Type
            </p>

            <h1 className="text-3xl md:text-4xl font-serif mb-3" style={{ color: archetype.color }}>
              {archetype.name}
            </h1>

            <p className="text-lg italic text-brand-dark/70 mb-6">
              "{archetype.tagline}"
            </p>

            <p className="text-brand-dark/60 text-sm leading-relaxed">
              {archetype.shortDescription}
            </p>

            <div className="mt-6 pt-4 border-t border-brand-dark/10">
              <p className="text-xs text-brand-dark/40">
                Only <strong>{archetype.percentage}</strong> of women share this type
              </p>
            </div>
          </motion.div>

          {/* ─── DETAILS PHASE ─── */}
          {phase === 'details' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-6"
            >
              {/* Share button */}
              <button
                onClick={handleShare}
                className="inline-flex items-center gap-2 bg-white border-2 border-brand-dark/10 text-brand-dark
                           px-6 py-3 rounded-full text-sm font-medium hover:border-brand-gold transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                </svg>
                Share My Result
              </button>

              {/* Teaser for full report */}
              <div className="bg-white rounded-2xl p-6 md:p-8 border border-brand-dark/5 text-left">
                <h3 className="font-serif text-xl text-brand-dark mb-3">
                  But here's what your answers <em>really</em> revealed...
                </h3>
                <p className="text-brand-dark/60 text-sm leading-relaxed mb-6">
                  {name}, your quiz responses paint a much deeper picture than just your archetype.
                  Your full coaching report traces the thread from your childhood through to your
                  relationships, career, body, and finances — showing you the ONE hidden belief
                  that's been running everything.
                </p>

                <div className="space-y-2 mb-6">
                  {['Your specific limiting belief pattern — and exactly where it came from',
                    'The mind-body connection: why stress shows up where it does for you',
                    'The paradox keeping you stuck (and how to break it)',
                    'A personalised coaching message written for YOUR answers',
                    'Your recommended next step based on YOUR unique profile'
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-brand-dark/70">
                      <span className="text-brand-gold mt-0.5">✓</span>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>

                {userId && reportReady ? (
                  <a
                    href={`/report/${userId}`}
                    className="block w-full bg-brand-dark text-brand-cream text-center px-8 py-4 rounded-full
                               font-medium hover:bg-brand-plum transition-colors"
                  >
                    Read {name}'s Full Coaching Report
                  </a>
                ) : userId ? (
                  <div className="text-center py-4">
                    <motion.div
                      className="inline-block w-5 h-5 border-2 border-brand-gold/30 border-t-brand-gold rounded-full"
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                    />
                    <p className="text-sm text-brand-dark/40 mt-2">
                      Your personalised report is being generated...
                    </p>
                  </div>
                ) : (
                  <p className="text-sm text-brand-dark/40 text-center">
                    Report generation requires a database connection.
                    See SETUP.md for instructions.
                  </p>
                )}
              </div>

              {/* Full archetype description */}
              <div className="bg-white/50 rounded-2xl p-6 md:p-8 text-left">
                <h3 className="font-serif text-lg text-brand-dark mb-4">
                  About {archetype.name}
                </h3>
                {archetype.fullDescription.split('\n\n').map((para, i) => (
                  <p key={i} className="text-brand-dark/60 text-sm leading-relaxed mb-3">
                    {para}
                  </p>
                ))}
              </div>
            </motion.div>
          )}
        </motion.div>
      )}

      {/* Footer */}
      <div className="mt-12 text-center">
        <p className="text-[10px] text-brand-dark/20 tracking-[0.2em] uppercase">
          Marisa Peer &middot; Rapid Transformational Therapy
        </p>
      </div>
    </div>
  );
}

export default function ResultsPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-brand-cream" />}>
      <ResultsContent />
    </Suspense>
  );
}
